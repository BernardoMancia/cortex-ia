import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")
stdin, stdout, stderr = ssh.exec_command("echo 'JKyRd<^Wg$)&D:Z3' | sudo -S ufw status")
print(stdout.read().decode('utf-8'))
ssh.close()
