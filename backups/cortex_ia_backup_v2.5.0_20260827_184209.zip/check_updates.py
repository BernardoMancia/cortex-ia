import requests
TOKEN = "8879384050:AAHmeJ2n70BE_daRcCgfnrMYRW_H0ceL4A0"
url = f"https://api.telegram.org/bot{TOKEN}/getUpdates"
resp = requests.get(url, params={'offset': 0, 'timeout': 5})
print(resp.json())
