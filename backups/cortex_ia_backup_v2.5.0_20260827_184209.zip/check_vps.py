import paramiko
import os

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")
stdin, stdout, stderr = ssh.exec_command("ls -la /home/servico/")
content = stdout.read().decode('utf-8', errors='replace')
with open("ls_home.txt", "w", encoding="utf-8") as f:
    f.write(content)

stdin, stdout, stderr = ssh.exec_command("ps aux | grep python")
content = stdout.read().decode('utf-8', errors='replace')
with open("ps_aux.txt", "w", encoding="utf-8") as f:
    f.write(content)

ssh.close()
print("Done checking VPS.")
