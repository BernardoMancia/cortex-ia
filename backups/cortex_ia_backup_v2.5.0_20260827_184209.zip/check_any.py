import paramiko
import os

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")
stdin, stdout, stderr = ssh.exec_command("grep -rn 'solicitado via Telegram' /home/servico/ 2>/dev/null | grep -v 'engine.log'")
content = stdout.read().decode('utf-8', errors='replace')
with open("grep_any.txt", "w", encoding="utf-8") as f:
    f.write(content)
ssh.close()
print("Done.")
