import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")
stdin, stdout, stderr = ssh.exec_command("sqlite3 /home/servico/cortex-ia/data/cortex.db 'select timestamp, message_type, content from telegram_logs order by id desc limit 10;'")
content = stdout.read().decode('utf-8', errors='replace')
with open("db_logs.txt", "w", encoding="utf-8") as f:
    f.write(content)
ssh.close()
print("Done.")
