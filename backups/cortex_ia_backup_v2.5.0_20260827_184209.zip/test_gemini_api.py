import paramiko
from scp import SCPClient

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect('82.112.245.99', 22, 'servico', r'JKyRd<^Wg$)&D:Z3')

with SCPClient(ssh.get_transport()) as scp:
    scp.put(r'f:\Projetos\cortex-ia\analysis\sentiment.py', '/home/servico/cortex-ia/analysis/sentiment.py')
print('File uploaded')

stdin, stdout, stderr = ssh.exec_command('sudo -S systemctl restart cortex-ia.service')
stdin.write(r'JKyRd<^Wg$)&D:Z3' + '\n')
stdin.flush()
stdout.read()
print('Service restarted')

ssh.close()
print('Done!')
