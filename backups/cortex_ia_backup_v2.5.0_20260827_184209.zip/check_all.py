import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")
stdin, stdout, stderr = ssh.exec_command("find /home/servico/ -name '*.py' -exec grep -Hn 'Status do C' {} \\; 2>/dev/null")
content = stdout.read().decode('utf-8', errors='replace')
with open("grep_all.txt", "w", encoding="utf-8") as f:
    f.write(content)
ssh.close()
print("Done.")
