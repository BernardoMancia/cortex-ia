import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")

print("Forcing kill of all processes...")
ssh.exec_command('pkill -9 -f "python.*main.py"')
import time
time.sleep(2)

print("Deleting files...")
ssh.exec_command('rm -f /home/servico/cortex-ia/data/cortex.db')
ssh.exec_command('rm -f /home/servico/cortex-ia/data/simulator_state.json')

ssh.close()
