import paramiko
import time

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")

print("Parando processos...")
ssh.exec_command('pkill -f "python.*main.py"')
time.sleep(2)

print("Apagando banco de dados e estado do simulador...")
ssh.exec_command('rm -f /home/servico/cortex-ia/data/cortex.db')
ssh.exec_command('rm -f /home/servico/cortex-ia/data/simulator_state.json')

print("Feito.")
ssh.close()
