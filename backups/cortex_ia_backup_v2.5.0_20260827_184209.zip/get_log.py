import paramiko
import os

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")
stdin, stdout, stderr = ssh.exec_command("cat /home/servico/cortex-ia/logs/engine.log")
log = stdout.read().decode('utf-8', errors='replace')
with open("full_engine_log.txt", "w", encoding="utf-8") as f:
    f.write(log)
ssh.close()
print("Downloaded full log.")
