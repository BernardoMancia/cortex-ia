import paramiko

ssh = paramiko.SSHClient()
ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
ssh.connect("82.112.245.99", 22, "servico", "JKyRd<^Wg$)&D:Z3")
stdin, stdout, stderr = ssh.exec_command("sed -i 's/TELEGRAM_CHAT_ID=.*/TELEGRAM_CHAT_ID=-1003841061385/g' /home/servico/cortex-ia/.env")
print(stdout.read().decode('utf-8'))
print(stderr.read().decode('utf-8'))
ssh.close()
